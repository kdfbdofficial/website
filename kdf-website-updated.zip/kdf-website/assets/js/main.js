/* ============================================
   KNOWLEDGE DEVELOPMENT FOUNDATION
   Main JavaScript
   ============================================ */

// ---- NAVBAR SCROLL ----
const navbar = document.getElementById('navbar');
window.addEventListener('scroll', () => {
  if (window.scrollY > 60) navbar.classList.add('scrolled');
  else navbar.classList.remove('scrolled');
});

// ---- HAMBURGER MENU ----
const hamburger = document.querySelector('.hamburger');
const mobileMenu = document.querySelector('.mobile-menu');
if (hamburger && mobileMenu) {
  hamburger.addEventListener('click', () => {
    hamburger.classList.toggle('open');
    mobileMenu.classList.toggle('open');
  });
  document.querySelectorAll('.mobile-menu a').forEach(a => {
    a.addEventListener('click', () => {
      hamburger.classList.remove('open');
      mobileMenu.classList.remove('open');
    });
  });
}

// ---- PARTICLES ----
function createParticles() {
  const container = document.querySelector('.hero-particles');
  if (!container) return;
  for (let i = 0; i < 30; i++) {
    const p = document.createElement('div');
    p.className = 'particle';
    p.style.cssText = `
      left: ${Math.random() * 100}%;
      top: ${80 + Math.random() * 20}%;
      animation-duration: ${4 + Math.random() * 6}s;
      animation-delay: ${Math.random() * 5}s;
      width: ${1 + Math.random() * 3}px;
      height: ${1 + Math.random() * 3}px;
    `;
    container.appendChild(p);
  }
}
createParticles();

// ---- COUNTER ANIMATION ----
function animateCounter(el, target, suffix = '') {
  const duration = 2000;
  const start = performance.now();
  const update = (time) => {
    const progress = Math.min((time - start) / duration, 1);
    const eased = 1 - Math.pow(1 - progress, 3);
    el.textContent = Math.floor(eased * target) + suffix;
    if (progress < 1) requestAnimationFrame(update);
  };
  requestAnimationFrame(update);
}

// ---- INTERSECTION OBSERVER ----
const observer = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.classList.add('visible');
      if (entry.target.classList.contains('stat-num')) {
        const raw = entry.target.dataset.count || entry.target.textContent;
        const suffix = entry.target.dataset.suffix || '';
        const num = parseInt(raw.replace(/\D/g, ''));
        if (!isNaN(num)) animateCounter(entry.target, num, suffix);
      }
      observer.unobserve(entry.target);
    }
  });
}, { threshold: 0.15 });

document.querySelectorAll('.fade-in, .stat-num').forEach(el => observer.observe(el));

// ---- ACTIVE NAV LINK ----
const currentPage = window.location.pathname.split('/').pop() || 'index.html';
document.querySelectorAll('.nav-links a, .mobile-menu a').forEach(a => {
  if (a.getAttribute('href') === currentPage) a.classList.add('active');
});

// ---- ACCESS KEY ----
const WEB3FORMS_KEY = '10403538-f813-4194-9b38-23ab9a113424';

// ---- CONTACT FORM ----
const contactForm = document.getElementById('contactForm');
if (contactForm) {
  contactForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const btn = contactForm.querySelector('button[type="submit"]');
    const originalText = btn.innerHTML;
    btn.innerHTML = 'Sending...';
    btn.disabled = true;

    // Build plain JSON (no file) — most reliable for Web3Forms free tier
    const data = {
      access_key: WEB3FORMS_KEY,
      subject: 'New Message — KDF Website Contact Form',
      from_name: 'KDF Website',
      name: contactForm.querySelector('[name="name"]').value,
      email: contactForm.querySelector('[name="email"]').value,
      subject_field: contactForm.querySelector('[name="subject"]').value,
      message: contactForm.querySelector('[name="message"]').value,
    };

    try {
      const res = await fetch('https://api.web3forms.com/submit', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
        body: JSON.stringify(data)
      });
      const json = await res.json();
      if (json.success) {
        contactForm.innerHTML = `<div style="text-align:center;padding:40px 0">
          <div style="font-size:52px;margin-bottom:14px">✅</div>
          <h3 style="font-family:'Playfair Display',serif;color:var(--navy);font-size:22px;margin-bottom:10px">Message Received!</h3>
          <p style="color:var(--text-mid)">Thank you for contacting us. We'll get back to you within 24 hours.</p>
        </div>`;
      } else {
        throw new Error(json.message || 'Failed');
      }
    } catch (err) {
      console.error('Contact form error:', err);
      btn.innerHTML = originalText;
      btn.disabled = false;
      alert('Something went wrong. Please email us: kdf.bd.official@gmail.com or WhatsApp: 01879700541');
    }
  });
}

// ---- REGISTRATION FORM ----
const regForm = document.getElementById('regForm');
if (regForm) {
  // File upload label
  const fileInput = document.getElementById('paymentScreenshot');
  const fileLabel = document.getElementById('fileLabel');
  if (fileInput && fileLabel) {
    fileInput.addEventListener('change', () => {
      if (fileInput.files[0]) {
        fileLabel.textContent = '✅ ' + fileInput.files[0].name;
        fileLabel.style.color = 'var(--gold)';
      }
    });
  }

  regForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const btn = regForm.querySelector('button[type="submit"]');
    const originalText = btn.innerHTML;
    btn.innerHTML = 'Submitting...';
    btn.disabled = true;

    // Collect all text fields as JSON (skip file — Web3Forms free doesn't support files)
    const get = (name) => {
      const el = regForm.querySelector(`[name="${name}"]`);
      return el ? el.value : '';
    };

    const payload = {
      access_key: WEB3FORMS_KEY,
      subject: 'New GK Genius Registration — KDF',
      from_name: 'KDF Registration',
      // participant info
      name: get('name'),
      email: get('email'),
      mobile: get('mobile'),
      whatsapp: get('whatsapp'),
      institution: get('institution'),
      class_grade: get('class_grade'),
      // payment info
      sender_number: get('sender_number'),
      trx_id: get('trx_id'),
      reference: get('reference'),
      note: 'Payment screenshot submitted separately by participant. Please verify Trx.ID manually.'
    };

    try {
      const res = await fetch('https://api.web3forms.com/submit', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
        body: JSON.stringify(payload)
      });
      const json = await res.json();
      if (json.success) {
        document.getElementById('regFormContent').style.display = 'none';
        document.getElementById('successMsg').classList.add('show');
      } else {
        throw new Error(json.message || 'Failed');
      }
    } catch (err) {
      console.error('Registration form error:', err);
      btn.innerHTML = originalText;
      btn.disabled = false;
      alert('Something went wrong. Please contact us: kdf.bd.official@gmail.com or WhatsApp: 01879700541');
    }
  });
}
